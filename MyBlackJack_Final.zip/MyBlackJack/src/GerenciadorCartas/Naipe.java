package GerenciadorCartas;

/**
 *
 * @author Mlaker and the people
 */
public enum Naipe {

PAUS, OUROS, COPAS, ESPADAS;

    
}
